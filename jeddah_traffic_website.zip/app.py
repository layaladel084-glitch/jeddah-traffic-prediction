import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier

st.set_page_config(
    page_title="التنبؤ بالازدحام المروري في جدة",
    page_icon="🚦",
    layout="centered"
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap');
html, body, [class*="css"] { font-family: 'Cairo', sans-serif; }
.block-container { max-width: 900px; padding-top: 2rem; }
.hero {
  background: linear-gradient(135deg, #102a43 0%, #176b87 100%);
  padding: 28px; border-radius: 22px; color: white; margin-bottom: 20px;
}
.hero h1 { color: white; font-size: 2rem; margin-bottom: 8px; }
.hero p { color: #e7f6ff; margin: 0; font-size: 1rem; }
.small-note { color: #52616b; font-size: 0.9rem; }
.result { border-radius: 18px; padding: 20px; margin-top: 15px; border: 1px solid #d9e2ec; }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero" dir="rtl">
  <h1>🚦 نظام التنبؤ بالازدحام المروري</h1>
  <p>مدينة جدة · نموذج تجريبي باستخدام تعلّم الآلة</p>
</div>
""", unsafe_allow_html=True)

st.markdown("<div dir='rtl'>اختاري الشارع واليوم والوقت، ثم اضغطي على زر التنبؤ لعرض نتيجة النموذج.</div>", unsafe_allow_html=True)

ROADS = [
    "طريق الملك عبدالعزيز",
    "طريق المدينة المنورة",
    "شارع فلسطين",
    "طريق الأمير سلطان"
]
DAYS = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"]

@st.cache_resource
def get_model():
    # If the trained model from Google Colab is placed beside app.py, use it.
    model_path = os.path.join(os.path.dirname(__file__), "traffic_model.pkl")
    if os.path.exists(model_path):
        try:
            return joblib.load(model_path), "نموذجك المحفوظ من Google Colab"
        except Exception:
            pass

    # Standalone fallback: create clearly synthetic sample data and train a real ML model.
    rng = np.random.default_rng(42)
    road_effect = {
        "طريق الملك عبدالعزيز": 18,
        "طريق المدينة المنورة": 14,
        "شارع فلسطين": 12,
        "طريق الأمير سلطان": 10
    }
    day_effect = {
        "الأحد": 15, "الاثنين": 15, "الثلاثاء": 14,
        "الأربعاء": 14, "الخميس": 18, "الجمعة": -10, "السبت": -5
    }
    rows = []
    for _ in range(5000):
        road = rng.choice(ROADS)
        day = rng.choice(DAYS)
        hour = int(rng.integers(0, 24))
        rush = 0
        if 6 <= hour <= 9:
            rush += 30
        if 13 <= hour <= 16:
            rush += 15
        if 17 <= hour <= 20:
            rush += 35
        score = 20 + road_effect[road] + day_effect[day] + rush + rng.normal(0, 10)
        level = "منخفض" if score < 40 else ("متوسط" if score < 70 else "مرتفع")
        rows.append([road, day, hour, level])
    data = pd.DataFrame(rows, columns=["الشارع", "اليوم", "الساعة", "مستوى_الازدحام"])
    X = data[["الشارع", "اليوم", "الساعة"]]
    y = data["مستوى_الازدحام"]
    preprocessor = ColumnTransformer([
        ("categorical", OneHotEncoder(handle_unknown="ignore"), ["الشارع", "اليوم"]),
        ("numeric", "passthrough", ["الساعة"])
    ])
    model = Pipeline([
        ("preprocessing", preprocessor),
        ("classifier", RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    model.fit(X, y)
    return model, "نموذج مدرّب داخل الموقع على بيانات اصطناعية"

model, model_source = get_model()

with st.form("prediction_form"):
    st.markdown("### بيانات الرحلة")
    road = st.selectbox("اختاري الشارع", ROADS, index=0)
    day = st.selectbox("اختاري اليوم", DAYS, index=0)
    col1, col2 = st.columns(2)
    with col1:
        hour = st.selectbox("الساعة", list(range(24)), index=7, format_func=lambda h: f"{h:02d}:00")
    with col2:
        minute = st.selectbox("الدقائق", [0, 15, 30, 45], index=2, format_func=lambda m: f"{m:02d}")
    submitted = st.form_submit_button("توقّع الازدحام 🚦", use_container_width=True)

if submitted:
    sample = pd.DataFrame([{"الشارع": road, "اليوم": day, "الساعة": int(hour)}])
    prediction = model.predict(sample)[0]
    probs = model.predict_proba(sample)[0]
    classes = model.named_steps["classifier"].classes_
    prob_df = pd.DataFrame({"المستوى": classes, "احتمال النموذج": probs})
    prob_df = prob_df.sort_values("احتمال النموذج", ascending=False)

    color = {"منخفض": "#e7f7ee", "متوسط": "#fff4d6", "مرتفع": "#fde8e7"}.get(prediction, "#edf2f7")
    icon = {"منخفض": "🟢", "متوسط": "🟠", "مرتفع": "🔴"}.get(prediction, "🚦")
    st.markdown(f"""
    <div class="result" dir="rtl" style="background:{color}">
      <h2>{icon} مستوى الازدحام المتوقع: {prediction}</h2>
      <p>الشارع: <b>{road}</b></p>
      <p>اليوم: <b>{day}</b> · الوقت: <b>{hour:02d}:{minute:02d}</b></p>
    </div>
    """, unsafe_allow_html=True)
    st.markdown("#### احتمالات النموذج")
    st.bar_chart(prob_df.set_index("المستوى"))
    st.caption(f"مصدر النموذج: {model_source}")

st.divider()
st.markdown("""
### عن المشروع
هذا نموذج أولي لمشروع التنبؤ بالازدحام المروري في مدينة جدة باستخدام تعلّم الآلة.

**تنبيه أكاديمي:** البيانات المستخدمة اصطناعية ومولّدة لأغراض التجربة، وليست قياسات فعلية لحركة المرور في جدة. النتائج توضح طريقة عمل النموذج فقط، ولا تمثل حالة المرور الحقيقية أو تنبؤًا موثوقًا بها.
""")
with st.expander("معلومات المشروع"):
    st.write("اسم المشروع: نظام ذكي للتنبؤ بالازدحام المروري في مدينة جدة باستخدام الذكاء الاصطناعي وتعلّم الآلة")
    st.write("اسم الطالبة / قائدة المجموعة: أضيفي اسمك هنا")
    st.write("اسم الدكتور: أضيفي اسم الدكتور هنا")
    st.write("أعضاء المجموعة: أضيفي أسماء أعضاء المجموعة هنا")
